<template>
    <div class="auto-apreensao-id">
        <PageTitle icon="fa fa-file-o" text=" Registro - " :main="auto.id" sub=""/>
        <b-container fluid="sm">
            <hr>
            <div class="titulo"><h2>Identificação no Registro da Ocorência</h2></div>
            <hr>
            <b-row>
                <b-col md="3" sn="12" >
                    <b-form-group label="Data Sistema:" label-for="ro-dtSistema">
                        <b-form-input id="ro-dtSistema" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.dth_sistema" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12" >
                    <b-form-group label="Data da Ocorência:" label-for="ro-dtOcorrencia">
                        <b-form-input id="ro-dtOcorrencia" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.dt_ocorrencia" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="produto:" label-for="auto-produto">
                        <b-form-input id="auto-produto" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.produto" :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="3" sn="12">
                    <b-form-group label="Matrícula" label-for="auto-matricula">
                        <b-form-input id="auto-matricula" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.matricula" :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="3" sn="12">
                    <b-form-group label="Condutor" label-for="auto-condutor">
                        <b-form-input id="auto-condutor" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.condutor" :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="3" sn="12">
                    <b-form-group label="Função Condutor" label-for="auto-funcao">
                        <b-form-input id="auto-funcao" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.funcao_condutor" :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            
            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Recebedor:" label-for="auto-recebedor">
                        <b-form-input id="auto-recebedor" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.recebedor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Doc Recebedor:" label-for="auto-doc-recebedor">
                        <b-form-input id="auto-doc-recebedor" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.doc_recebedor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Função Recebedor:" label-for="auto-funcao">
                        <b-form-input id="auto-funcao" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.funcao_recebedor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Lotação Recebedor:" label-for="auto-lotacao">
                        <b-form-input id="auto-lotacao" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.lotacao_recebedor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Inspetoria:" label-for="auto-inspetoria">
                        <b-form-input id="auto-inspetoria" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.inspetoria" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Superior de Serviço:" label-for="auto-superior-servico">
                        <b-form-input id="auto-superior-servico" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.superior_servico" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="1" sn="12">
                    <b-form-group label="RO:" label-for="auto-ro">
                        <b-form-input id="auto-ro" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.ro_Id" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
        </b-container>
    </div>
</template>

<script>
import { baseApiUrl } from '../../../global'
import axios from 'axios'
import PageTitle from '../../template/PageTitle'

export default {
    name: 'AutoDeApreensaoId',
    components: { PageTitle },
    data: function() {
        return {
            auto: {},
            autos: [],
        }
    },
    mounted() {
        const url = `${baseApiUrl}/autoapreensao/${this.$route.params.id}`
        axios.get(url).then(res => this.auto = res.data);
    }
}
</script>

<style>
.auto-apreensao-id{
    padding-top: 20px;
}
</style>

