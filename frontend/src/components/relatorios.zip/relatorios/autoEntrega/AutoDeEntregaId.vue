<template>
<div>
    <div class="auto-entrega-id" id="print-auto-entrega">
        <PageTitle icon="fa fa-file-o" text=" Registro - " :main="auto.id" sub=""/>
        <b-container fluid="sm">
            <hr>
            <div class="titulo"><h2>Identificação no Registro da Ocorência</h2></div>
            <hr>
            <b-row>
                <b-col md="3" sn="12" >
                    <b-form-group label="Data Sistema:" label-for="ro-dtSistema">
                        <b-form-input id="ro-dtSistema" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.dth_sistema" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12" >
                    <b-form-group label="Data da Ocorência:" label-for="ro-dtOcorrencia">
                        <b-form-input id="ro-dtOcorrencia" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.dt_ocorrencia" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Natureza:" label-for="auto-natureza">
                        <b-form-input id="auto-natureza" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.natureza_ocorrencia" :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="3" sn="12">
                    <b-form-group label="Matrícula" label-for="auto-matricula">
                        <b-form-input id="auto-matricula" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.matricula" :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="3" sn="12">
                    <b-form-group label="Condutor" label-for="auto-condutor">
                        <b-form-input id="auto-condutor" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.condutor" :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="3" sn="12">
                    <b-form-group label="Função Condutor" label-for="auto-funcao">
                        <b-form-input id="auto-funcao" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.funcao_condutor" :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            
            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Conduzido:" label-for="auto-conduzido">
                        <b-form-input id="auto-conduzido" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.conduzido" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Doc Conduzido:" label-for="auto-doc-conduzido">
                        <b-form-input id="auto-doc-conduzido" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.doc_conduzido" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Recebedor:" label-for="auto-recebedor">
                        <b-form-input id="auto-recebedor" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.recebedor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Doc Recebedor:" label-for="auto-doc-recebedor">
                        <b-form-input id="auto-doc-recebedor" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.doc_recebedor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            
             <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Função Recebedor:" label-for="auto-funcao">
                        <b-form-input id="auto-funcao" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.funcao_recebedor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Lotação Recebedor:" label-for="auto-lotacao">
                        <b-form-input id="auto-lotacao" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.lotacao_recebedor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Testemunha 1:" label-for="auto-testemunha1">
                        <b-form-input id="auto-testemunha1" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.testemunha1" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Doc Testemunha 1:" label-for="auto-doc-testemunha1">
                        <b-form-input id="auto-doc-testemunha1" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.doc_testemunha1" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>

            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Testemunha 2:" label-for="auto-testemunha2">
                        <b-form-input id="auto-testemunha2" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.testemunha2" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Doc Testemunha 2:" label-for="auto-doc-testemunha2">
                        <b-form-input id="auto-doc-testemunha2" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.doc_testemunha2" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="3" sn="12">
                    <b-form-group label="Integridade Conduzido:" label-for="auto-integridade">
                        <b-form-input id="auto-integridade" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.integrid_conduzido" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Inspetoria:" label-for="auto-inspetoria">
                        <b-form-input id="auto-inspetoria" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.inspetoria" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Superior de Serviço:" label-for="auto-superior-servico">
                        <b-form-input id="auto-superior-servico" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.superior_servico" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="1" sn="12">
                    <b-form-group label="RO:" label-for="auto-ro">
                        <b-form-input id="auto-ro" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="auto.ro_Id" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            <b-row>
                <b-col md="12" sn="12">
                    <b-form-group label="Relato:" label-for="auto-relato">
                        <b-form-textarea
                            id="textarea"
                            v-model="auto.relato"
                            :readonly="true"
                            rows="3"
                            max-rows="6"
                        ></b-form-textarea>
                    </b-form-group>
                </b-col>
            </b-row>
        </b-container>
        </div>
        <p>
        <input type="button" value="Criar PDF" id="btnImprimir" @click="CriaPDF()" />
    </p>
    </div>
    
</template>

<script>
import { baseApiUrl } from '../../../global'
import axios from 'axios'
import PageTitle from '../../template/PageTitle'

export default {
    name: 'AutoDeEntregaId',
    components: { PageTitle },
    data: function() {
        return {
            auto: {},
            autos: [],
        }
    },
    methods:{
        CriaPDF() {
        var minhaTabela = document.getElementById('print-auto-entrega').innerHTML;
        var style = "<style>";
        style = style + "table {width: 100%;font: 20px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";
        // CRIA UM OBJETO WINDOW
        var win = window.open('', '', 'height=700,width=700');
        win.document.write('<html><head>');
        win.document.write('<title>Empregados</title>');   // <title> CABEÇALHO DO PDF.
        win.document.write(style);                                     // INCLUI UM ESTILO NA TAB HEAD
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(minhaTabela);                          // O CONTEUDO DA TABELA DENTRO DA TAG BODY
        win.document.write('</body></html>');
        win.document.close(); 	                                         // FECHA A JANELA
        win.print();                                                            // IMPRIME O CONTEUDO
    }
    },
    mounted() {
        const url = `${baseApiUrl}/autoentrega/${this.$route.params.id}`
        axios.get(url).then(res => this.auto = res.data);
    }
}
</script>

<style>
.auto-entrega-id{
    padding-top: 20px;
}
</style>

