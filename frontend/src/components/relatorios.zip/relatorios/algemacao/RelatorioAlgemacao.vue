<template>
  <div class="relatorio-algemacao">
    <PageTitle icon="fa fa-file" main=" RELATÓRIO DE ALGEMAÇÃO" sub="" />
    <hr />
    <div class="conteudo">
      <b-table
        hover
        :items="relatorios"
        :fields="fields"
        bordered="bordered"
        head-variant="dark"
        table-variant="light"
      >
        <template slot="links" slot-scope="data">
          <router-link
            :to="{ name: 'relatorioAlgemacaoId', params: { id: data.item.id } }"
          >
            Detalhes
          </router-link>
        </template>
      </b-table>
      <b-pagination
        size="md"
        v-model="page"
        :total-rows="count"
        :per-page="limit"
      />
    </div>
  </div>
</template>

<script>
import PageTitle from "../../template/PageTitle";
import { baseApiUrl } from "../../../global";
import axios from "axios";

export default {
  name: "RelatorioAlgemacao",
  components: { PageTitle },
  data: function () {
    return {
      user: {},
      relatorios: [],
      page: 1,
      limit: 0,
      count: 0,
      fields: [
        { key: "id", label: "ID", sortable: true },
        { key: "dt_ocorrencia", label: "Data da Ocorrencia", sortable: true },
        { key: "condutor", label: "Condutor", sortable: true },
        { key: "links", label: "Ações" },
      ],
    };
  },
  methods: {
    loadRelatorios() {
      const url = `${baseApiUrl}/relatorioalgemacao?page=${this.page}`;
      axios.get(url).then((res) => {
        this.relatorios = res.data.data;
        this.count = res.data.count;
        this.limit = res.data.limitStats;
      });
    },
  },
  watch: {
    $route() {
      this.relatorios = [];
      this.page = 1;
    },
    page() {
      this.loadRelatorios();
    },
  },
  mounted() {
    this.loadRelatorios();
  },
};
</script>

<style>
.relatorio-algemacao {
  padding: 20px;
}
</style>

