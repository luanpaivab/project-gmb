<template>
  <div class="relatorio-algemacaoId">
    <PageTitle
      icon="fa fa-folder"
      text=" Relatório - "
      :main="relatorio.id"
      sub=""
    />
    <hr />
    <b-container fluid="sm">
      <div class="titulo">
        <h2>Relatório Explicativo para Utilização de Algemas</h2>
      </div>
      <hr />
      <b-row>
        <b-col md="3" sn="12">
          <b-form-group label="Data/Hora do Sistema:" label-for="dt-sistema">
            <b-form-input
              id="dt-sistema"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.dt_sistema"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
        <b-col md="3" sn="12">
          <b-form-group label="Data Ocorrência:" label-for="dt-ocorrencia">
            <b-form-input
              id="dt-ocorrencia"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.dt_ocorrencia"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
        <b-col md="4" sn="12">
          <b-form-group label="Condutor:" label-for="condutor">
            <b-form-input
              id="condutor"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.condutor"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
      </b-row>
      <b-row>
        <b-col md="3">
          <b-form-group label="Função do Condutor:" label-for="funcao-condutor">
            <b-form-input
              id="funcao-condutor"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.funcao_condutor"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
        <b-col md="3">
          <b-form-group label="Autor Presumível:" label-for="autor-presumivel">
            <b-form-input
              id="autor-presumivel"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.autor_presumivel"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
        <b-col md="2">
          <b-form-group label="RG/CPF:" label-for="doc-autor">
            <b-form-input
              id="doc-autor"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.doc_autor"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
      </b-row>
      <b-row>
        <b-col md="5">
          <b-form-group label="Justificativa da Algemação:" label-for="justificativa">
            <b-form-input
              id="justificativa"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.jutificativa_algemacao"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
      </b-row>
      <b-row>
        <b-col>
          <b-form-group label="Relato da Ocorrência:" label-for="relato">
            <b-form-input
              id="relato"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.relatorio_ocorrencia"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
      </b-row>
      <b-row>
        <b-col md="3">
          <b-form-group label="Coordenador:" label-for="coordenador">
            <b-form-input
              id="coordenador"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.coordenador"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
        <b-col md="3">
          <b-form-group label="Inspetoria:" label-for="inspetoria">
            <b-form-input
              id="inspetoria"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.inspetoria"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
        <b-col md="3">
          <b-form-group label="Superior de Serviço:" label-for="superior-servico">
            <b-form-input
              id="superior-servico"
              type="text"
              style="border: 1px solid rgba(0, 0, 0, 0.8)"
              v-model="relatorio.superior_servico"
              required
              :readonly="true"
            />
          </b-form-group>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
import PageTitle from "@/components/template/PageTitle";
import { baseApiUrl } from "../../../global";
import axios from "axios";

export default {
  name: "RelatorioAlgemacaoId",
  components: { PageTitle },
  data: function () {
    return {
      relatorio: {},
    };
  },
  mounted() {
    const url = `${baseApiUrl}/relatorioalgemacao/${this.$route.params.id}`;
    axios.get(url).then((res) => (this.relatorio = res.data));
  },
};
</script>

<style>
.relatorio-algemacaoId{
  padding-top: 20px;
}
</style>

