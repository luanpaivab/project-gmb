<template>
    <div class="sim-id">
        <PageTitle icon="fa fa-file-o" text=" Registro - " :main="sim.id" sub=""/>
        <b-container fluid="sm">
            <hr>
            <div class="titulo"><h2>Identificação no Registro da Ocorência</h2></div>
            <hr>
            <b-row>
                <b-col md="3" sn="12" >
                    <b-form-group label="Data Sistema:" label-for="sim-dtSistema">
                        <b-form-input id="sim-dtSistema" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.dth_sistema" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12" >
                    <b-form-group label="Data da Ocorência:" label-for="sim-dtOcorrencia">
                        <b-form-input id="sim-dtOcorrencia" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.dt_ocorrencia" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Hora da Chamada:" label-for="sim-hrChamada">
                        <b-form-input id="sim-hr_chamada" type="time" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.hr_chamada" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Hora de término:" label-for="sim-termino">
                        <b-form-input id="sim-termino" type="time" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.hr_termino" required
                            :readonly="true"
                            />
                    </b-form-group>
                </b-col>
            </b-row>

            <b-row>
                <b-col md="4" sn="12">
                    <b-form-group label="Solicitante:" label-for="sim-solicit">
                        <b-form-input id="sim-solicit" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.solicit" :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="3" sn="12">
                    <b-form-group label="Documento" label-for="sim-doc">
                        <b-form-input id="sim-doc" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.doc" :readonly="true"/>
                    </b-form-group>
                </b-col>
                 <b-col md="2" sn="12">
                    <b-form-group label="Telefone" label-for="sim-tel">
                        <b-form-input id="sim-tel" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.tel" :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            
            <b-row>
                <b-col md="8" sn="12">
                    <b-form-group label="Endereço:" label-for="sim-endereco">
                        <b-form-input id="sim-endereco" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.endereco" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Estado:" label-for="sim-estado">
                        <b-form-input id="sim-estado" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.estado" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Cidade:" label-for="sim-cidade">
                        <b-form-input id="sim-cidade" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.cidade" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
            
             <b-row>
                <b-col md="4" sn="12">
                    <b-form-group label="Bairro:" label-for="sim-bairro">
                        <b-form-input id="sim-bairro" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.bairro" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Número:" label-for="sim-num">
                        <b-form-input id="sim-num" type="number" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.num" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="CEP:" label-for="sim-cep">
                        <b-form-input id="sim-cep" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.cep" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>
             <hr>

            <div class="titulo"><h2>Partes Envolvidas na Ocorência</h2></div>

            <hr>

            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Nome do Suspeito:" label-for="sim-suspeito">
                        <b-form-input id="sim-suspeito" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.nome_suspeito" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Raça Suspeito:" label-for="sim-raca">
                        <b-form-input id="sim-raca" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.classif_racial" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="2" sn="12">
                    <b-form-group label="Gênero Suspeito:" label-for="sim-genAutor">
                        <b-form-input id="sim-genAutor" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.classif_genero" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Idade Suspeito:" label-for="sim-faixa-etaria">
                        <b-form-input id="sim-faixa-etaria" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.faixa_etaria" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>

            </b-row>
            <b-row>
                <b-col md="2" sn="12">
                    <b-form-group label="Guarnição:" label-for="sim-guarnicao">
                        <b-form-input id="sim-guarnicao" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.guarnicao_apoio" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Superior de Serviço:" label-for="sim-superior">
                        <b-form-input id="sim-superior" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.superior_serv" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="3" sn="12">
                    <b-form-group label="Encarregado Ocorrência:" label-for="sim-encarregado">
                        <b-form-input id="sim-encarregado" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.encarregado_ocor" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>

            <b-row>
                <b-col md="3" sn="12">
                    <b-form-group label="Encaminhamento:" label-for="sim-encaminhamento">
                        <b-form-input id="sim-encaminhamento" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.encaminhamento" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
                <b-col md="6" sn="12">
                    <b-form-group label="Arma Suspeito:" label-for="sim-arma-suspeito">
                        <b-form-input id="sim-arma-suspeito" type="text" style="border: 1px solid rgba(0, 0, 0,0.8);"
                            v-model="sim.arma_suspeito" required
                            :readonly="true"/>
                    </b-form-group>
                </b-col>
            </b-row>

            <b-row>
                <b-col md="9" sn="12">
                    <b-form-group label="Histórico:" label-for="auto-relato">
                        <b-form-textarea
                            id="textarea"
                            v-model="sim.historico"
                            :readonly="true"
                            rows="3"
                            max-rows="6"
                        ></b-form-textarea>
                    </b-form-group>
                </b-col>
            </b-row>
        </b-container>
    </div>
</template>

<script>
import { baseApiUrl } from '../../../global'
import axios from 'axios'
import PageTitle from '../../template/PageTitle'

export default {
    name: 'SimId',
    components: { PageTitle },
    data: function() {
        return {
            sim: {},
            sims: [],
        }
    },
    mounted() {
        const url = `${baseApiUrl}/sim/${this.$route.params.id}`
        axios.get(url).then(res => this.sim = res.data);
    }
}
</script>

<style>
.sim-id{
    padding-top: 20px;
}
</style>

